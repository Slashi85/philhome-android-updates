# SPHERE Tapo C575D Bridge 0.1.7 – lesendes Testpaket

Vollständiges, manuell installierbares Testpaket auf Basis eurer Bridge 0.1.6.
Dies ist keine automatisch veröffentlichte oder installierte Integration.

## Inhalt und unveränderte Funktionen

`custom_components/sphere_tapo/` enthält __init__.py, manifest.json und services.yaml.
Nur zwei diagnostische GET-Probes wurden ergänzt; die Versionsnummer ist 0.1.7,
damit sich die geladene Testversion vom Original unterscheiden lässt.
Alle bestehenden Control-Aktionen, IR/Farbmodus-Setter, Kanalzuordnungsparameter,
Sperren für unabhängiges Weißlicht, Sicherheitsfilter, HA-Verbindung und Lock sind
identisch zur bereitgestellten 0.1.6. In services.yaml wurde lediglich eine
ungültige, unquotierte Beschreibung mit Doppelpunkt korrekt als String quotiert. Es gibt keine neuen Setter oder Zugangsdaten.

Die zusätzlichen Leseversuche verwenden getDayNightModeConfig:
- day_night_common_list: image.name=["common"], chn_id=[1,2]
- day_night_explicit_common_chn: image.name=["common_chn"], chn_id=[1,2]

Ihre Unterstützung auf der C575D ist noch unbestätigt. Fehlermeldungen dieser
Probes sind Testergebnisse, keine Aufforderung für weitere Schreibversuche.

## Sicherung

1. Gesamtes vorhandenes `/config/custom_components/sphere_tapo/` sichern, z.B.
   als `/config/sphere_tapo-backup-0.1.6/`, außerhalb von custom_components.
   Am besten zusätzlich ein normales Home-Assistant-Backup erstellen.
2. Falls die installierte Bridge lokale Änderungen enthält: den Dateiunterschied
   zuerst prüfen; dieses Paket basiert auf der hochgeladenen unveränderten 0.1.6.
3. Die bestehenden Kameraeinstellungen vor dem Gerätetest notieren. Dieses Paket
   schreibt bei der Installation oder beim Start keine Kameraeinstellungen.

## Installation, ausschließlich manuell

1. ZIP in einen separaten Arbeitsordner entpacken. Enthaltene SHA256SUMS können
   dort mit `sha256sum -c SHA256SUMS` geprüft werden.
2. Nur den Ordner `custom_components/sphere_tapo` in das bestehende
   `/config/custom_components/` kopieren und die drei gesicherten Bridge-Dateien
   ersetzen. Nicht den gesamten custom_components-Ordner ersetzen und keine
   anderen Integrationen überschreiben.
3. Die bestehende YAML-Konfiguration (`sphere_tapo:`) unverändert behalten.
   Keine neue TP-Link-Integration, Kontoverbindung oder Zugangsdaten anlegen.
4. Home Assistant regulär vollständig neu starten, damit die Python-Dateien
   wirklich neu geladen werden. Ein bloßer erneuter Aufruf von Inspect reicht
   nicht; der Dienst wird bei bereits registrierter Integration nicht ersetzt.
   Der Neustart unterbricht HA-vermittelte Streams vorübergehend. SPHERE-App,
   go2rtc-Konfiguration und Player-Architektur werden dadurch nicht geändert.
5. In Entwicklerwerkzeuge → Aktionen `sphere_tapo.inspect` ausführen. Die Antwort
   muss die beiden oben genannten zusätzlichen Keys unter `probes` enthalten.
   Fehlen sie, ist die neue Python-Datei nicht geladen; nicht weiter testen.
   Vorhandene funktionierende IR/Farb-Steuerung muss nicht erneut getestet werden.

## Kleiner Gerätetest

1. Beide Linsen in der Tapo-App Automatisch; einmal Inspect.
2. Nur Detail auf Tag, Weitwinkel weiter Automatisch; einmal Inspect.
3. Detail wieder auf den ursprünglichen Wert zurückstellen; einmal Inspect und
   beide App-Einstellungen kontrollieren. Wenn der ursprüngliche Wert nicht Auto
   war, genau diesen ursprünglichen Wert wiederherstellen.

Alle drei Abfragen:

```yaml
action: sphere_tapo.inspect
data: {}
```

Nur `probes.day_night_common_list` und `probes.day_night_explicit_common_chn` für
alle drei Zeitpunkte zurückgeben, inklusive responds/reason und values.image.
Keine Zugangsdaten, Ingress-URLs oder unbereinigten Logs teilen.

Erfolg erfordert eindeutig getrennte Werte: während Detail=Tag Kanal 1=auto,
Kanal 2=off, nach Rückstellung beide ursprünglichen Werte. Ein erfolgreiches GET
oder erneut ein unzugeordneter common-Wert genügt nicht. Dies bestätigt höchstens
den Reader, noch keinen neuen Setter. Bei Fehlermeldungen oder fehlender
kanalbezogener Rückmeldung keine zusätzlichen API-Schreibversuche durchführen.

## Vollständiger Rückbau

1. Die Kameraeinstellung aus dem Test in der Tapo-App wiederherstellen.
2. Die gesicherte komplette Bridge 0.1.6 nach
   `/config/custom_components/sphere_tapo/` zurückkopieren. Falls nur Dateien
   gesichert wurden, mindestens __init__.py, manifest.json und services.yaml
   wiederherstellen. Die YAML-Konfiguration unverändert lassen.
3. Home Assistant erneut vollständig neu starten.
4. Inspect muss wieder ohne die beiden zusätzlichen Diagnose-Keys antworten.
   Beide Kameraeinstellungen in der Tapo-App kontrollieren.

Die Sicherung erst nach erfolgreichem Rückbau oder Abschluss des Tests löschen.

## Lokale Prüfung

Python-Syntax, Manifest und Services-YAML geprüft. AST-Vergleich bestätigt, dass
außerhalb der PROBES-Deklaration sämtlicher Python-Code mit 0.1.6 identisch ist.
Zwölf lokale Simulationstests bestanden. Dies ersetzt keine Geräteprüfung der
zusätzlichen GET-Selektoren. Es wurde keine HA-Installation angesprochen.
