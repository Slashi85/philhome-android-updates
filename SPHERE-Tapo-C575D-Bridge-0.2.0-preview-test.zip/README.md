# SPHERE C575D Bridge 0.2.0 – zusammenhängender Preview-Gerätetest

Vollständige Bridge auf Basis eurer installierten 0.1.7. Keine neue Kameraverbindung
oder Zugangsdaten. Bestehende privacy/PTZ-/Nachtsichttyp-Befehle bleiben erhalten.
Neue Funktionen sind technisch begründet, aber Setter/LED-Wirkung auf eurer Kamera
noch im abschließenden Gerätetest zu bestätigen. Keine automatische Installation.

## Sicherung und Installation

1. Den gesamten bestehenden Ordner `/config/custom_components/sphere_tapo` z.B.
   nach `/config/sphere_tapo-backup-0.1.7` sichern (außerhalb custom_components),
   zusätzlich normales HA-Backup empfohlen. Kameraeinstellungen beider Linsen
   und Lampen vor dem Test notieren. Keine Zugangsdaten teilen.
2. ZIP separat entpacken; SHA256SUMS prüfen. Nur den enthaltenen Ordner
   `custom_components/sphere_tapo` in `/config/custom_components` kopieren.
   Vier Dateien: __init__.py, camera_controls.py, manifest.json, services.yaml.
   Die neue camera_controls.py muss mitkopiert werden. Keine anderen Integrationen,
   HA-Konfiguration oder go2rtc-Dateien ersetzen. `sphere_tapo:` unverändert lassen.
3. HA vollständig neu starten (unterbricht HA-vermittelte Streams vorübergehend).
   Dies ändert keine SPHERE-Wiedergabearchitektur. Dienste allein neu aufzurufen
   lädt die bereits registrierten Python-Handler nicht neu.
4. Entwicklerwerkzeuge → Aktionen: `sphere_tapo.camera_status`, `data: {}`.
   Erwartet api_version=1 und channels 1/2 mit day_night. Die Android-Preview lädt
   genau diesen Dienst; alte Bridge-Versionen liefern keine bedienbare Oberfläche.

## Technische Steuerwege und Grenzen

- Tag/Nacht/Auto: setDayNightModeConfig → image.common_chn[channel].inf_type.
  Reader: getDayNightModeConfig → name=["common"], chn_id=[1,2], common_chn.
  Reader am Gerät bestätigt; Setter unabhängig in pytapo 3.4.18 implementiert.
- Manuelles Licht: pytapo setForceWhitelampState → setLdc,
  image.switch_chn[channel].force_wtl_state, oder nur bei ausschließlich globalem
  eindeutigen Reader image.switch.force_wtl_state. getLdc ist der kanonische
  pytapo-Reader. Keine night_color-Umschaltung als Licht-Ersatz.
- Per-Kanal-Licht nur bei zwei eindeutigen lesbaren on/off-Kanalwerten. Ausschließlich
  globaler lesbarer Zustand bedeutet geräteweiten Kandidaten, NICHT eine belegte
  Wirkung auf beide LEDs. Teilweise/fehlende/unklare Werte sperren die Schaltfunktion.
- force_wtl_state ist ein erzwungener Konfigurationszustand, kein LED-Sensor.
  Off kann die Zwangsbeleuchtung aufheben, während automatische Farb-Nachtsicht
  die LEDs weiter verwendet. Ob echte unabhängige Ein/Aus-Wirkung möglich ist,
  muss physisch geprüft werden. Lesbare Intensität allein schaltet nichts frei.
- Kein Rückfall auf andere Setter, floodlight, reverse_wtl_status oder get/set
  night_vision_mode. Keine Aktion oder automatische Rückstellung beim Start.
- Gerät muss tatsächlich C575D sein; eine stabile gehashte Gerätebindung wird
  vor jedem neuen Befehl geprüft. Die Bridge nutzt weiterhin eure feste bestehende
  Kamera-Verbindung. Keine Android-IP-/Kamera-Passwort-Konfiguration.
- Neue Requests: explizites Ein-Request-multipleRequest mit retry_count=0.
  Verhindert sowohl normalen SDK-Retry als auch fehlende-Antwort-Requery-Fallback.
  Kein neuer Protocol-Client, kein Direktzugriff auf die Transport-Authentifizierung.
  Unbekanntes Protokoll oder fehlende No-Retry-Schnittstelle blockiert Befehle.
- Ein Setter; frische GETs beider Linsen danach. Der gesamte vorher bekannte
  Zustand bis auf das angeforderte Feld muss gleich bleiben. Auch Mode/Nachtsicht-
  Seiteneffekte von Lampenbefehlen werden erkannt. Keine automatischen Write-Retries
  oder Rollbacks. Fehler/Timeout können trotz bereits erfolgter Änderung auftreten.
- configuration_verified bedeutet Konfiguration nachgelesen, NICHT physisch
  verifiziert. physical_verification_required bleibt ausdrücklich true.

## Eine kompakte abschließende Gerätetest-Anleitung

Beleuchtung während Modusvergleichen möglichst konstant halten. Vorher beide
Originalmodi und Lampeneinstellungen in der Tapo-App notieren, camera_status
aufbewahren. Bridge 0.2.0 und die dazugehörige signierte SPHERE-Preview installieren.

1. In SPHERE Weitwinkelbild antippen → kleiner Modusbutton → Tag, Nacht, Auto
   jeweils einmal wählen. Nach jeder Auswahl: passende App-Einstellung und Bild
   prüfen, Detail-Einstellung unverändert. Danach Originalmodus wiederherstellen.
   Dasselbe für Detail; im Querformat Hauptlinse auswählen (PiP-Tausch unverändert)
   und Modusbutton verwenden. Auto kann bei gleicher Helligkeit dasselbe Bild wie
   Nacht liefern; ggf. in einem getrennten kurzen Helligkeitswechsel Auto-Reaktion
   prüfen, danach beide Originaleinstellungen wiederherstellen.
2. Licht öffnen. Ist die Funktion gesperrt, lamp_scope/lamp_reason aus camera_status
   zurückgeben; keine alternativen Setter probieren. Bei Kanalsteuerung jede Linse
   einmal Ein → Aus (oder den ursprünglichen Zustand), tatsächliche LEDs beobachten,
   andere Lampe sowie beide Modus-/Nachtsicht-Einstellungen prüfen. Bei geräteweitem
   Kandidaten nur einmal Ein → Aus, dokumentieren welche LEDs reagieren; keine
   getrennte Linsenfähigkeit behaupten. Wenn Aus LEDs nicht ausschaltet, automatische
   Beleuchtung beachten und Originalzustände in Tapo-App restaurieren. Dies ist ein
   negatives/bedingtes Ergebnis, keine bestätigte unabhängige Aus-Funktion.
3. Bei jeder unklaren Rückmeldung sofort stoppen. Beide tatsächlichen Zustände in
   der Tapo-App kontrollieren und manuell restaurieren, in SPHERE Neu lesen.
   Keine wiederholten Schreibversuche auf Verdacht. Abschließend camera_status
   lesen: Originalzustände wiederhergestellt. Beide Streams, Rotation, PiP und
   WLAN/Mobilfunk einmal wie gewohnt prüfen; keine Playback-Logik wurde umgebaut.

Ergebnis einmal gesammelt melden: Modus pro Linse (Tag/Nacht/Auto), lamp_scope,
physische Lampenwirkung pro Linse, Rückmeldung/Seiteneffekte, Originale restauriert.
Keine Zugangsdaten, Rohlogs, Kamera-/Ingress-URLs erforderlich.

## Rückbau

1. Originalzustände manuell in Tapo-App wiederherstellen.
2. HA stoppen bzw. den vollständigen Bridge-Ordner durch die gesicherte 0.1.7
   ersetzen; neue camera_controls.py entfernen, falls Dateien einzeln rückkopiert
   werden. YAML-Konfiguration unverändert lassen. HA vollständig neu starten.
3. Bei Bedarf vorherige signierte SPHERE-Preview ef4278b installieren; Installation
   einer älteren Version kann je nach Android einen manuellen Rückbau erfordern.
   Vorherige APK behalten; keine Daten löschen, nur um einen Downgrade zu erzwingen.
   Beide App-/Kamerazustände und Streams kontrollieren.

## Quellen und Tests

pytapo Setter-Commit 8c97d90d26c8129d9b8c051cd8d82c4f7cb424d1 und Methoden
get/setForceWhitelampState, __get/__setImageSwitch im geprüften Commit
 a2f0fbd1fa4f4fc79e9fb5df4e9893ca55a3ba8c.
https://github.com/JurajNyiri/pytapo/commit/8c97d90d26c8129d9b8c051cd8d82c4f7cb424d1
https://github.com/JurajNyiri/pytapo/blob/a2f0fbd1fa4f4fc79e9fb5df4e9893ca55a3ba8c/pytapo/__init__.py

18 automatisierte Bridge-Simulationstests mit allen sechs Modus-Payloads,
Lampen-Payloads, Scope-/Identitäts-/Protokoll-Guards, fehlenden/ignorierten Antworten,
Timeout ohne Write-Retry, Seiteneffekten und Readback-Ausfall. Nicht am Gerät
verifiziert, keine HA-Installation durch den Entwicklungsagenten.

Ein fehlender force_wtl_state-Nachweis ist kein Beweis, dass die Kamera keine
Lampen besitzt. Der alternative getWhitelampStatus/reverseWhitelampStatus-Weg
steht für einen Legacy-/teils zeitbegrenzten Toggle ohne belegte unabhängige
C575D-Kanalzuordnung. Er wird nicht als zuverlässiger expliziter Ein/Aus-Schalter
ausgegeben. Bei fehlendem Lampen-Reader bleiben die belegten Modus-Reader bedienbar.
