"""SPHERE C575D bridge over the *existing* Home Assistant TP-Link device.

The bridge does not create its own connection and never handles credentials.
Only predeclared commands can be sent.  All discovery is read-only.
"""
from __future__ import annotations

import asyncio
import logging
from typing import Any

import voluptuous as vol
from kasa import Module
from homeassistant.core import HomeAssistant, ServiceCall, SupportsResponse
from homeassistant.exceptions import HomeAssistantError

_LOGGER = logging.getLogger(__name__)

DOMAIN = "sphere_tapo"
HOST = "192.168.0.98"

# Exactly the known API method + payload combinations implemented upstream.
PROBES: dict[str, tuple[str, dict[str, Any]]] = {
    "privacy": ("getLensMaskConfig", {"lens_mask": {"name": ["lens_mask_info"]}}),
    "night_vision": ("getLightFrequencyInfo", {"image": {"name": "common"}}),
    "white_light": ("getWhitelampConfig", {"image": {"name": ["switch"]}}),
    # Specific per-lens night vision mode, distinct from global inf_type.
    "night_vision_mode": ("getNightVisionModeConfig", {"image": {"name": ["switch"]}}),
    "image_switches": ("getLdc", {"image": {"name": ["switch"]}}),
    "day_night_config": ("getDayNightModeConfig", {"image": {"name": "common"}}),
    # Diagnostic GET-only selector variants; support on C575D is not yet verified.
    "day_night_common_list": ("getDayNightModeConfig", {"image": {"name": ["common"], "chn_id": [1, 2]}}),
    "day_night_explicit_common_chn": ("getDayNightModeConfig", {"image": {"name": ["common_chn"], "chn_id": [1, 2]}}),
    "night_vision_capability": ("getNightVisionCapability", {"image_capability": {"name": ["supplement_lamp"]}}),
    "floodlight": ("getFloodlightStatus", {"floodlight": {"get_floodlight_status": ""}}),
    "alarm": ("getSirenStatus", {"siren": {}}),
    "video_quality": ("getVideoQualities", {"video": {"name": ["main"]}}),
    "video_capabilities": ("getVideoCapability", {"video_capability": {"name": ["main", "minor"]}}),
}

# Only known, non-secret image/video/switch-state attributes leave HA.
ALLOWED_KEYS = {
    "lens_mask", "lens_mask_info", "enabled", "image", "common", "common_chn",
    "switch", "switch_chn", "inf_type", "night_vision_mode", "force_wtl_state",
    "night_vision", "light_status", "get_wtl_status", "floodlight",
    "get_floodlight_status", "status", "intensity", "intensity_level",
    "siren", "volume", "duration", "video", "video_capability", "main", "minor",
    "resolution", "resolutions", "quality", "bitrate", "bit_rate", "fps",
    "frame_rate", "width", "height", "encode_type", "codec", "chn_id",
    "stream_type", "stream", "supported", "stream1", "stream2", "stream6",
    "image_capability", "supplement_lamp", "night_vision_mode_range",
    "wtl_force_time", "wtl_intensity_level", "light_freq_mode", "wtl_auto",
    "force_wtl_state", "light_type", "wtl_status", "ldc", "brightness",
}

CONTROL_ACTIONS = {
    "privacy_on", "privacy_off", "siren_test", "siren_stop",
    "night_ir", "night_color", "night_smart",
    "floodlight_on", "floodlight_off", "white_light_on", "white_light_off",
}


def _safe(data: Any, depth: int = 0) -> Any:
    """Return only allowlisted diagnostics, never tokens or account details."""
    if depth > 8:
        return None
    if isinstance(data, dict):
        return {
            str(key): _safe(value, depth + 1)
            for key, value in data.items()
            if str(key) in ALLOWED_KEYS or (str(key).isdigit() and len(str(key)) <= 2)
        }
    if isinstance(data, (list, tuple)):
        return [_safe(x, depth + 1) for x in data[:30]]
    if isinstance(data, (bool, int, float)):
        return data
    if isinstance(data, str):
        return data[:100]
    return None


def _device(hass: HomeAssistant):
    """Borrow the already authenticated TP-Link device, never login again."""
    for entry in hass.config_entries.async_entries("tplink"):
        runtime = getattr(entry, "runtime_data", None)
        coordinator = getattr(runtime, "parent_coordinator", None)
        device = getattr(coordinator, "device", None)
        if device is not None and getattr(device, "host", None) == HOST:
            return device, coordinator
    raise HomeAssistantError(
        "Die C575D ist nicht als aktive TP-Link-Smart-Home-Verbindung verfügbar. "
        "Es wurde keine neue Kamera-Verbindung aufgebaut."
    )


async def _query(device, command: str, params: dict[str, Any]) -> dict[str, Any]:
    """Use the same python-kasa protocol as Home Assistant's TP-Link integration."""
    result = await asyncio.wait_for(device._query_helper(command, params), timeout=12)
    if not isinstance(result, dict) or command not in result:
        raise HomeAssistantError("Keine verwertbare Antwort der Kamera")
    value = result[command]
    if not isinstance(value, dict) or not value:
        raise HomeAssistantError("Kamera unterstützt diese Abfrage derzeit nicht")
    if value.get("error_code", 0) not in (0, None):
        raise HomeAssistantError("Kamera hat die Abfrage abgelehnt")
    return value


async def _probe(device, feature: str, channel: int | None = None) -> dict[str, Any]:
    """Read-only capability check; errors never break whole inspection."""
    command, params = PROBES[feature]
    if channel is not None:
        if feature not in ("night_vision", "white_light", "night_vision_mode", "image_switches", "day_night_config"):
            return {"responds": False, "reason": "not_channel_specific"}
        params = {"image": {"name": "common" if feature in ("night_vision", "day_night_config") else ["switch"], "chn_id": [channel]}}
    try:
        value = await _query(device, command, params)
        return {"responds": True, "values": _safe(value)}
    except Exception as err:
        return {"responds": False, "reason": type(err).__name__}


async def async_setup(hass: HomeAssistant, config: dict[str, Any]) -> bool:
    """YAML-based setup: register actions, with no device access at startup."""
    if hass.services.has_service(DOMAIN, "inspect"):
        return True
    operation_lock = asyncio.Lock()
    _LOGGER.info("SPHERE Tapo Bridge registering local control services")

    async def inspect(call: ServiceCall) -> dict[str, Any]:
        device, _ = _device(hass)
        async with operation_lock:
            modules = getattr(device, "modules", {})
            result = {
                "model": "C575D",
                "host": HOST,
                "using_existing_tplink_connection": True,
                "existing_modules": {
                    "privacy": Module.LensMask in modules,
                    "alarm": Module.Alarm in modules,
                    "ptz": Module.PanTilt in modules,
                },
                "probes": {},
            }
            for name in PROBES:
                result["probes"][name] = await _probe(device, name)
            # Read-only: do not infer which channel is wide-angle/detail yet.
            # getNightVisionModeConfig did not reflect an observed Tapo UI change;
            # compare alternative standard getters without writing to the camera.
            result["channel_diagnostics"] = {
                str(channel): {
                    "night_vision": await _probe(device, "night_vision", channel),
                    "white_light": await _probe(device, "white_light", channel),
                    "night_vision_mode": await _probe(device, "night_vision_mode", channel),
                    "image_switches": await _probe(device, "image_switches", channel),
                    "day_night_config": await _probe(device, "day_night_config", channel),
                }
                for channel in (1, 2)
            }
            return result

    async def control(call: ServiceCall) -> dict[str, Any]:
        action: str = call.data["action"]
        channel: int | None = call.data.get("channel")
        device, coordinator = _device(hass)
        modules = getattr(device, "modules", {})

        async with operation_lock:
            if action in ("privacy_on", "privacy_off"):
                privacy = modules.get(Module.LensMask)
                if privacy is not None:
                    # The real camera lens mask, not merely UI video hiding.
                    await privacy.set_enabled(action == "privacy_on")
                else:
                    if not (await _probe(device, "privacy"))["responds"]:
                        raise HomeAssistantError("Privatsphäre-Steuerung nicht bestätigt")
                    await _query(device, "setLensMaskConfig", {
                        "lens_mask": {
                            "lens_mask_info": {
                                "enabled": "on" if action == "privacy_on" else "off"
                            }
                        }
                    })
            elif action in ("siren_test", "siren_stop"):
                siren = modules.get(Module.Alarm)
                if siren is not None:
                    if action == "siren_stop":
                        await siren.stop()
                    else:
                        # Deliberately short and low volume; only on explicit action.
                        await siren.play(duration=2, volume=1)
                else:
                    if not (await _probe(device, "alarm"))["responds"]:
                        raise HomeAssistantError("Alarm-Steuerung nicht bestätigt")
                    if action == "siren_test":
                        # Set safety limits before enabling alarm.
                        await _query(device, "setSirenConfig", {
                            "siren": {"duration": 2, "volume": "1"}
                        })
                    await _query(device, "setSirenStatus", {
                        "siren": {"status": "on" if action == "siren_test" else "off"}
                    })
            elif action in ("night_ir", "night_color", "night_smart"):
                # Official pytapo channel-specific payload. Never send a global
                # setDayNightModeConfig command to this C575D again.
                modes = {
                    "night_ir": "inf_night_vision",
                    "night_color": "wtl_night_vision",
                    "night_smart": "md_night_vision",
                }
                if channel not in (1, 2):
                    raise HomeAssistantError(
                        "Bitte explizit channel: 1 oder channel: 2 angeben. "
                        "Die Zuordnung zu Weitwinkel/Detail ist noch unbekannt."
                    )
                desired = modes[action]
                capability = await _probe(device, "night_vision_capability")
                supported = (
                    capability.get("values", {})
                    .get("image_capability", {})
                    .get("supplement_lamp", {})
                    .get("night_vision_mode_range", [])
                )
                if not capability.get("responds") or desired not in supported:
                    raise HomeAssistantError(
                        "Gewünschter Nachtsichtmodus nicht durch Kamera bestätigt"
                    )

                async def read_modes():
                    # Require *actual* switch_chn values, never global fallback.
                    data = {}
                    for ch in (1, 2):
                        response = await _probe(device, "night_vision_mode", ch)
                        if not response.get("responds"):
                            raise HomeAssistantError(
                                "Kanalbezogene Zustandsabfrage fehlgeschlagen"
                            )
                        mode = (
                            response.get("values", {})
                            .get("image", {})
                            .get("switch_chn", {})
                            .get(str(ch), {})
                            .get("night_vision_mode")
                        )
                        if mode not in supported:
                            raise HomeAssistantError(
                                "Kanalbezogene Nachtsichtantwort fehlt oder ist ungültig"
                            )
                        data[ch] = mode
                    return data

                before = await read_modes()
                if before[channel] == desired:
                    return {
                        "confirmed": True,
                        "changed": False,
                        "reason": "Kanal war bereits auf diesem Modus",
                        "channel": channel,
                        "state": desired,
                        "channels": {str(k): v for k, v in before.items()},
                    }

                write_issue = None
                try:
                    # SET may legitimately return an empty body; verify via GET.
                    await asyncio.wait_for(
                        device._query_helper(
                            "setNightVisionModeConfig",
                            {"image": {
                                "chn_id": [channel],
                                "switch_chn": {str(channel): {
                                    "night_vision_mode": desired,
                                }},
                            }},
                        ),
                        timeout=12,
                    )
                except Exception as err:
                    # A server-side write can succeed even if its reply is
                    # rejected by the python-kasa response parser.
                    write_issue = type(err).__name__

                await asyncio.sleep(0.4)
                after = await read_modes()
                if after[channel] != desired:
                    raise HomeAssistantError(
                        "Nachtsicht wurde nicht bestätigt: "
                        f"Kanal {channel} meldet weiterhin {after[channel]}; "
                        f"vorher {before[channel]}. "
                        f"Antwortproblem: {write_issue or 'keines'}"
                    )
                if any(after[ch] != before[ch] for ch in (1, 2) if ch != channel):
                    raise HomeAssistantError(
                        "WARNUNG: Auch der andere Kanal hat seinen Zustand "
                        "verändert. Bitte in der Tapo-App beide prüfen. "
                        f"Vorher: {before}; Nachher: {after}"
                    )
                try:
                    await coordinator.async_request_refresh()
                except Exception as err:
                    # A refresh failure must not turn an already-confirmed
                    # camera change into a misleading operation error.
                    _LOGGER.warning("Camera changed but HA refresh failed: %s", type(err).__name__)
                return {
                    "confirmed": True,
                    "changed": True,
                    "channel": channel,
                    "mode": desired,
                    "before": {str(k): v for k, v in before.items()},
                    "after": {str(k): v for k, v in after.items()},
                    "write_reply_issue": write_issue,
                    "other_channel_unchanged": True,
                }
            elif action in ("white_light_on", "white_light_off"):
                if channel is None:
                    raise HomeAssistantError(
                        "Weißlicht benötigt einen ausdrücklich ausgewählten Kanal (1 oder 2). "
                        "Die physische Zuordnung ist noch nicht bestätigt."
                    )
                if not (await _probe(device, "white_light", channel))["responds"]:
                    raise HomeAssistantError("Weißlicht-Steuerung nicht bestätigt")
                raise HomeAssistantError(
                    "Weißlicht-Schaltbefehle bleiben gesperrt, "
                    "bis die Kanalzuordnung überprüft ist."
                )
            elif action in ("floodlight_on", "floodlight_off"):
                if channel is not None:
                    raise HomeAssistantError("Flutlicht ist keine objektivspezifische Funktion")
                if not (await _probe(device, "floodlight"))["responds"]:
                    raise HomeAssistantError("Flutlicht-Steuerung nicht bestätigt")
                await _query(device, "manualFloodlightOp", {
                    "floodlight": {
                        "manual_floodlight_op": {
                            "action": "start" if action == "floodlight_on" else "stop"
                        }
                    }
                })
            else:
                raise HomeAssistantError("Unbekannte Aktion")

            await coordinator.async_request_refresh()
            return {"accepted": True, "action": action, "channel": channel}

    hass.services.async_register(
        DOMAIN, "inspect", inspect,
        supports_response=SupportsResponse.ONLY,
    )
    hass.services.async_register(
        DOMAIN, "control", control,
        schema=vol.Schema({
            vol.Required("action"): vol.In(CONTROL_ACTIONS),
            vol.Optional("channel"): vol.All(vol.Coerce(int), vol.In((1, 2))),
        }),
        supports_response=SupportsResponse.ONLY,
    )
    return True


