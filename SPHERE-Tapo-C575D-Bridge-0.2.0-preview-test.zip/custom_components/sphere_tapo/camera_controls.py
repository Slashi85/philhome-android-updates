"""Scoped C575D controls. Readback is not physical verification. No write retries."""
import asyncio
import hashlib
import inspect
from homeassistant.exceptions import HomeAssistantError

ACTIONS = {"day_night_day": "off", "day_night_night": "on", "day_night_auto": "auto"}
NEW_ACTIONS = set(ACTIONS) | {"white_light_on", "white_light_off"}


def identity(device):
    if not str(getattr(device, "model", "")).upper().startswith("C575D"):
        raise HomeAssistantError("Die tatsächliche C575D-Geräteidentität fehlt.")
    key = getattr(device, "mac", None) or getattr(device, "device_id", None)
    if not key:
        raise HomeAssistantError("Keine stabile Geräteidentität verfügbar.")
    return hashlib.sha256(str(key).encode()).hexdigest()


async def query_once(device, method, params):
    protocol = getattr(device, "protocol", None)
    query = getattr(protocol, "query", None)
    if type(protocol).__name__ != "SmartCamProtocol" or not callable(query) or "retry_count" not in inspect.signature(query).parameters:
        raise HomeAssistantError("Protokoll ohne nachgewiesenen No-Retry-Steuerweg. Kein Fallback.")
    # Explicit single-item envelope avoids SDK missing-response requery fallback.
    result = await asyncio.wait_for(query({"multipleRequest": {"requests": [
        {"method": method, "params": params}
    ]}}, retry_count=0), timeout=12)
    envelope = result.get("multipleRequest", {}) if isinstance(result, dict) else {}
    rows = envelope.get("responses", []) if isinstance(envelope, dict) else []
    if not isinstance(rows, list) or len(rows) != 1 or not isinstance(rows[0], dict):
        raise HomeAssistantError("Keine eindeutige Kameraantwort.")
    row = rows[0]
    if row.get("method", method) != method or row.get("error_code", 0) not in (0, None):
        raise HomeAssistantError("Kamera hat den Aufruf nicht bestätigt.")
    return row.get("result") or {}


async def snapshot(device):
    key = identity(device)
    common = await query_once(device, "getDayNightModeConfig", {"image": {"name": ["common"], "chn_id": [1, 2]}})
    day = common.get("image", {}).get("common_chn", {})
    if any(day.get(str(ch), {}).get("inf_type") not in ("off", "on", "auto") for ch in (1, 2)):
        raise HomeAssistantError("Kanalbezogener Tag-/Nachtzustand fehlt. Kein globaler Fallback.")
    switch_issue = False
    try:
        switches = await query_once(device, "getLdc", {"image": {"name": ["switch"], "chn_id": [1, 2]}})
    except Exception:
        switches, switch_issue = {}, True  # Optional lamp reader must not disable valid mode controls.
    image = switches.get("image", {})
    by_channel = image.get("switch_chn", {})
    # The canonical pytapo force-white-lamp reader is getLdc / image.switch.
    lamps = {str(ch): by_channel.get(str(ch), {}).get("force_wtl_state") for ch in (1, 2)}
    night = {str(ch): by_channel.get(str(ch), {}).get("night_vision_mode") for ch in (1, 2)}
    global_lamp = image.get("switch", {}).get("force_wtl_state")
    if all(value in ("on", "off") for value in lamps.values()):
        lamp_scope, reason = "channel", "readable_per_channel_not_physically_verified"
    elif all(value is None for value in lamps.values()) and global_lamp in ("on", "off"):
        lamp_scope, reason = "device", "device_scope_lens_effect_not_verified"
    else:
        lamp_scope, reason = "unsupported", "no_unambiguous_force_wtl_state"
    if lamp_scope != "unsupported" and any(value not in ("inf_night_vision", "wtl_night_vision", "md_night_vision") for value in night.values()):
        lamp_scope, reason = "unsupported", "no_full_independence_readback"
    if switch_issue:
        reason = "switch_reader_failed"
    return {"api_version": 1, "device_key": key,
            "channels": {str(ch): {"day_night": day[str(ch)]["inf_type"],
                "night_type": night[str(ch)], "lamp": lamps[str(ch)] if lamps[str(ch)] in ("on", "off") else None} for ch in (1, 2)},
            "lamp_scope": lamp_scope, "lamp_reason": reason,
            "device_lamp": global_lamp if lamp_scope == "device" else None,
            "physical_verification_required": True}


async def execute(device, action, channel, device_key):
    before = await snapshot(device)
    if device_key != before["device_key"]:
        raise HomeAssistantError("Gerätezuordnung geändert. Neu laden, nicht erneut senden.")
    if action in ACTIONS:
        if channel not in (1, 2):
            raise HomeAssistantError("Expliziter Kanal 1 oder 2 erforderlich.")
        field, value, method = "day_night", ACTIONS[action], "setDayNightModeConfig"
        params = {"image": {"chn_id": [channel], "common_chn": {str(channel): {"inf_type": value}}}}
        current = before["channels"][str(channel)][field]
    elif action in ("white_light_on", "white_light_off"):
        # Preserve known night types to prove this is not a mode-switch workaround.
        if any(x["night_type"] not in ("inf_night_vision", "wtl_night_vision", "md_night_vision") for x in before["channels"].values()):
            raise HomeAssistantError("Nachtsichttyp für unabhängige Licht-Rückprüfung fehlt.")
        field, value, method = "lamp", "on" if action.endswith("_on") else "off", "setLdc"
        if before["lamp_scope"] == "channel" and channel in (1, 2):
            params = {"image": {"chn_id": [channel], "switch_chn": {str(channel): {"force_wtl_state": value}}}}
            current = before["channels"][str(channel)][field]
        elif before["lamp_scope"] == "device" and channel is None:
            params = {"image": {"switch": {"force_wtl_state": value}}}
            current = before["device_lamp"]
        else:
            raise HomeAssistantError("Unabhängiger Lampen-Schreibweg für diesen Scope nicht verfügbar.")
    else:
        raise HomeAssistantError("Unbekannte Kameraaktion.")
    if current == value:
        return {"attempted": False, "configuration_verified": True, "changed": False,
                "action": action, "channel": channel, "before": before, "after": before,
                "physical_verification_required": True}
    issue = None
    try:
        await query_once(device, method, params)
    except Exception as err:
        issue = type(err).__name__  # Never exception text, URLs or credentials.
    await asyncio.sleep(0.4)
    try:
        after = await snapshot(device)  # Fresh GETs; SET acknowledgement is not evidence.
    except Exception as err:
        return {"attempted": True, "configuration_verified": False, "changed": None,
                "action": action, "channel": channel, "before": before, "after": None,
                "write_reply_issue": issue, "readback_issue": type(err).__name__,
                "physical_verification_required": True}
    expected = {**before, "channels": {ch: dict(data) for ch, data in before["channels"].items()}}
    if field == "lamp" and before["lamp_scope"] == "device":
        expected["device_lamp"] = value
    else:
        expected["channels"][str(channel)][field] = value
    # Entire snapshot comparison checks other lens, night type and lamp/mode independence.
    verified = expected == after
    return {"attempted": True, "configuration_verified": verified,
            "changed": before != after, "action": action, "channel": channel,
            "before": before, "after": after, "write_reply_issue": issue,
            "physical_verification_required": True}
